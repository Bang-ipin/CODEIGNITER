<link href="<?=base_url('asset/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css');?>" rel="stylesheet" type="text/css"/>
		<link href="<?=base_url('asset/global/plugins/select2/css/select2.min.css');?>" rel="stylesheet" type="text/css" />
		<link href="<?=base_url('asset/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css');?>" rel="stylesheet" type="text/css" />
		<link href="<?=base_url('asset/global/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css');?>" rel="stylesheet" type="text/css" />
		<link href="<?=base_url('asset/global/plugins/jquery-tags-input/jquery.tagsinput.css');?>" rel="stylesheet" type="text/css" />
		<link href="<?=base_url('asset/global/plugins/typeahead/typeahead.css');?>" rel="stylesheet" type="text/css" >
