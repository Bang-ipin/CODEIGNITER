<script src="<?=base_url('asset/global/plugins/bootstrap-switch/js/bootstrap-switch.min.js');?>" type="text/javascript"></script>
		<script src="<?=base_url('asset/global/plugins/select2/js/select2.min.js');?>" type="text/javascript" ></script>
		<script src="<?=base_url('asset/global/plugins/jquery.validate.min.js');?>" type="text/javascript"  ></script>
		<script src="<?=base_url('asset/global/plugins/jquery-tags-input/jquery.tagsinput.min.js');?>" type="text/javascript"  ></script>
		<script src="<?=base_url('asset/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js');?>" type="text/javascript" ></script>
		<script src="<?=base_url('asset/global/plugins/bootstrap-touchspin/bootstrap.touchspin.js');?>" type="text/javascript" ></script>
		<script src="<?=base_url('asset/global/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min.js');?>" type="text/javascript" ></script>
		<script src="<?=base_url('asset/global/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js');?>" type="text/javascript" ></script>
		