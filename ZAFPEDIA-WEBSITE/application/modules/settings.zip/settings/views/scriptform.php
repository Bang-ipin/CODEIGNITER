<script src="<?=base_url('asset/admin/pages/scripts/komponen.js');?>" type="text/javascript"></script>
		<script src="<?=base_url('asset/admin/pages/scripts/validateform.js');?>" type="text/javascript"></script>
	