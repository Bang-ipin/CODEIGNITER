<?php defined('BASEPATH') or exit('No direct script access allowed');

class M_login extends CI_Model {
	
	public function get_user($u) {	
		$user =$this->db->escape_str($u);
		return $this->db->where('username',$user)
					->get('admin');
	}
	
}