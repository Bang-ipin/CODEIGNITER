<link href="<?=base_url('assets/global/plugins/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">
<script type="text/javascript" src="<?=base_url('assets/global/plugins/jquery.min.js');?>"></script>
<script type="text/javascript" src="<?=base_url('assets/global/plugins/bootstrap/js/bootstrap.min.js')?>"></script>
	<form action="<?=site_url('login');?>" method="post" role="form">

		<div class="form-group">
			<label>Username</label>
			<label class="input">
				<span class="input-icon input-icon-prepend fa fa-user"></span>
				<?php 
				echo form_input(array(
					'name' 			=> 'username', 
					'id' 			=> 'username', 
					'class' 		=> 'form-control placeholder-no-fix', 
					'autocomplete'	=> 'off', 
					'autofocus' 	=> 'autofocus',
					'placeholder'	=>'username',
					)); 
				?>
				<span class="tooltip tooltip-top-left"><i class="fa fa-user text-cyan-dark"></i> Please enter the username</span>
			</label>
			<div class="login-validasi"><?= form_error('username'); ?></div>
		</div>
		<div class="form-group">
			<label>Password</label>
			<label class="input">
				<span class="input-icon input-icon-prepend fa fa-key"></span>
				<?php 
					echo form_password(array(
						'name'		 	=> 'password', 
						'id'		 	=> 'password', 
						'class' 		=> 'form-control placeholder-no-fix', 
						'placeholder'	=>'password',
						
					)); 
				?>		
				<span class="tooltip tooltip-top-left"><i class="fa fa-key text-cyan-dark"></i> Please enter your password</span>
			</label>
			<div class="login-validasi"><?= form_error('password'); ?></div>
			<button type="button" class="btn-link btn-forgot-password">Forgot your password?</button>
		</div>

		<div class="row">
			<div class="col-xs-4">
				<button type="submit" name="submit" class="btn btn-info btn-block"><span class="glyphicon glyphicon-log-in"></span> Login</button>
			</div>
		</div>

</form>