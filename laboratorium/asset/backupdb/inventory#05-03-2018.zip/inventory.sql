#
# TABLE STRUCTURE FOR: admins
#

DROP TABLE IF EXISTS `admins`;

CREATE TABLE `admins` (
  `username` varchar(50) NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `nama_lengkap` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `level` varchar(20) NOT NULL,
  `toko` varchar(20) NOT NULL,
  `blokir` enum('Y','N') NOT NULL DEFAULT 'N',
  `foto` varchar(50) NOT NULL,
  `id_session` varchar(255) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `admins` (`username`, `password`, `nama_lengkap`, `level`, `toko`, `blokir`, `foto`, `id_session`) VALUES ('administrator', '$2y$10$V9pkY8dpqKz4tqygDH5osO8Epjz7WxCTERiuCFrUwtIPt/vqU8SCG', 'Owner', '01', '02,01', 'N', 'IMG-f10a.jpg', '$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW');
INSERT INTO `admins` (`username`, `password`, `nama_lengkap`, `level`, `toko`, `blokir`, `foto`, `id_session`) VALUES ('dinda', '$2y$10$5w75Mm8Pgavm3S5bqD44.OnyyKUa.9h61Ex5X6REEDDPm/HiGEAe6', 'dinda', '03', '01', 'N', 'ava-677f1.png', '$2y$10$mycKJnnvg9UG.wDnSoeJ/.XW/ofd6VowSaUcjskr80CXX19Am0AIy');
INSERT INTO `admins` (`username`, `password`, `nama_lengkap`, `level`, `toko`, `blokir`, `foto`, `id_session`) VALUES ('gudang', '$2y$10$YsMX/3f97/cZiZIs1M6n9uPQgSbLMKU8cpreSmrv.j6D4am9seP1G', 'Yunus', '02', '01,02', 'N', 'ava-677f.png', '$2y$10$iAvPWzAtFqAE.VDL0HC8kuJTSvRfpbknAmau2pKwEpS9G/ql4Oozy');
INSERT INTO `admins` (`username`, `password`, `nama_lengkap`, `level`, `toko`, `blokir`, `foto`, `id_session`) VALUES ('gunawan', '$2y$10$KFbJcko3cCDBa0F3nuC15ev6hEIBIbovw4b4p4JaNlcohraFY69Iu', 'gunawan', '03', '02', 'N', '', '$2y$10$VCVHzYumrjVEgn7OUa80WOkeWOND8819QM8A4/6tt3yi24x722D2e');
INSERT INTO `admins` (`username`, `password`, `nama_lengkap`, `level`, `toko`, `blokir`, `foto`, `id_session`) VALUES ('huda', '$2y$10$A2KaW6oUWKOl/8DdKFLTVeSODGjaLio9KoEsA02u1QQETT18EDe7e', 'huda', '03', '01', 'N', '', '$2y$10$ZCvvOGSWfUDT4zfKDzndxOajjPxc25dSlG/x/4o5uBi8Uz1vYfCR.');
INSERT INTO `admins` (`username`, `password`, `nama_lengkap`, `level`, `toko`, `blokir`, `foto`, `id_session`) VALUES ('user', '$2y$10$I0o.K8dajrMrVj1W9MI0COaqoc4o5VQdYht3y9TnSLF26LdU6ka6.', 'Hermawan', '03', '02', 'N', 'ava-8836.png', '$2y$10$P9krK7Yufa.ZYuR5NMVWKuPLVNGa2fXwKiFpm9r/OBEr.YJo.7el6');


#
# TABLE STRUCTURE FOR: barang
#

DROP TABLE IF EXISTS `barang`;

CREATE TABLE `barang` (
  `kode_barang` char(15) NOT NULL,
  `merk` varchar(255) NOT NULL,
  `type` enum('BNIB','BNWB','','') NOT NULL,
  `art` varchar(255) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `size` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga_beli` bigint(20) NOT NULL,
  `harga_jual` bigint(20) NOT NULL,
  PRIMARY KEY (`kode_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `barang` (`kode_barang`, `merk`, `type`, `art`, `nama_barang`, `size`, `qty`, `harga_beli`, `harga_jual`) VALUES ('ADD220', 'Adidas', 'BNWB', 'ADDSemiOri', 'Adidas Size 34 White', '34', '10', '210000', '540000');
INSERT INTO `barang` (`kode_barang`, `merk`, `type`, `art`, `nama_barang`, `size`, `qty`, `harga_beli`, `harga_jual`) VALUES ('ADD221', 'ADIDAS', 'BNIB', 'ADDORI3', 'Adidas Size 33 Black', '33', '10', '200000', '300000');
INSERT INTO `barang` (`kode_barang`, `merk`, `type`, `art`, `nama_barang`, `size`, `qty`, `harga_beli`, `harga_jual`) VALUES ('ADD222', 'Adidas', 'BNIB', 'ADDORIginal', 'Adidas Size 32 Black', '32', '10', '200000', '500000');
INSERT INTO `barang` (`kode_barang`, `merk`, `type`, `art`, `nama_barang`, `size`, `qty`, `harga_beli`, `harga_jual`) VALUES ('ADD223', 'Adidas', 'BNIB', 'ADDORI', 'Adidas Size 30 Black', '30', '10', '200000', '500000');
INSERT INTO `barang` (`kode_barang`, `merk`, `type`, `art`, `nama_barang`, `size`, `qty`, `harga_beli`, `harga_jual`) VALUES ('BAR223', 'Adidas', 'BNIB', 'ADDORIGINAL2', 'Adidas 23 black', '23', '10', '180000', '500000');
INSERT INTO `barang` (`kode_barang`, `merk`, `type`, `art`, `nama_barang`, `size`, `qty`, `harga_beli`, `harga_jual`) VALUES ('NK003', 'Nike', 'BNWB', '2323', 'Nike A12D1l4 40 Putih', '40', '10', '500000', '1000000');
INSERT INTO `barang` (`kode_barang`, `merk`, `type`, `art`, `nama_barang`, `size`, `qty`, `harga_beli`, `harga_jual`) VALUES ('SP0001', 'Speed', 'BNWB', '10ghRT', 'Speed 40 S Black', '40', '10', '60000', '150000');


#
# TABLE STRUCTURE FOR: barang1
#

DROP TABLE IF EXISTS `barang1`;

CREATE TABLE `barang1` (
  `kode_barang` char(15) NOT NULL,
  `merk` varchar(255) NOT NULL,
  `type` enum('BNIB','BNWB','','') NOT NULL,
  `art` varchar(255) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `size` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga_beli` bigint(20) NOT NULL,
  `harga_jual` bigint(20) NOT NULL,
  PRIMARY KEY (`kode_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `barang1` (`kode_barang`, `merk`, `type`, `art`, `nama_barang`, `size`, `qty`, `harga_beli`, `harga_jual`) VALUES ('ADD220', 'Adidas', 'BNWB', 'ADDSemiOri', 'Adidas Size 34 White', '34', '10', '210000', '540000');
INSERT INTO `barang1` (`kode_barang`, `merk`, `type`, `art`, `nama_barang`, `size`, `qty`, `harga_beli`, `harga_jual`) VALUES ('ADD221', 'ADIDAS', 'BNIB', 'ADDORI3', 'Adidas Size 33 Black', '33', '10', '200000', '300000');
INSERT INTO `barang1` (`kode_barang`, `merk`, `type`, `art`, `nama_barang`, `size`, `qty`, `harga_beli`, `harga_jual`) VALUES ('ADD222', 'Adidas', 'BNIB', 'ADDORIginal', 'Adidas Size 32 Black', '32', '10', '200000', '500000');
INSERT INTO `barang1` (`kode_barang`, `merk`, `type`, `art`, `nama_barang`, `size`, `qty`, `harga_beli`, `harga_jual`) VALUES ('ADD223', 'Adidas', 'BNIB', 'ADDORI', 'Adidas Size 30 Black', '30', '10', '200000', '500000');
INSERT INTO `barang1` (`kode_barang`, `merk`, `type`, `art`, `nama_barang`, `size`, `qty`, `harga_beli`, `harga_jual`) VALUES ('BAR223', 'Adidas', 'BNIB', 'ADDORIGINAL2', 'Adidas 23 black', '23', '10', '180000', '500000');
INSERT INTO `barang1` (`kode_barang`, `merk`, `type`, `art`, `nama_barang`, `size`, `qty`, `harga_beli`, `harga_jual`) VALUES ('NK003', 'Nike', 'BNWB', '2323', 'Nike A12D1l4 40 Putih', '40', '10', '500000', '1000000');


#
# TABLE STRUCTURE FOR: booking
#

DROP TABLE IF EXISTS `booking`;

CREATE TABLE `booking` (
  `kodebooking` char(15) NOT NULL,
  `tglbooking` date NOT NULL,
  `jatuh_tempo` date NOT NULL,
  `kode_pelanggan` char(5) NOT NULL,
  `pelanggan` varchar(50) NOT NULL,
  `keterangan` char(1) NOT NULL,
  `dp` double NOT NULL,
  `username` varchar(50) NOT NULL,
  `kode_barang` char(15) NOT NULL,
  `jmlbooking` int(11) NOT NULL,
  PRIMARY KEY (`kodebooking`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: booking1
#

DROP TABLE IF EXISTS `booking1`;

CREATE TABLE `booking1` (
  `kodebooking` char(15) NOT NULL,
  `tglbooking` date NOT NULL,
  `jatuh_tempo` date NOT NULL,
  `kode_pelanggan` char(5) NOT NULL,
  `pelanggan` varchar(50) NOT NULL,
  `keterangan` char(1) NOT NULL,
  `dp` double NOT NULL,
  `username` varchar(50) NOT NULL,
  `kode_barang` char(15) NOT NULL,
  `jmlbooking` int(11) NOT NULL,
  PRIMARY KEY (`kodebooking`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `ip_address` varchar(45) NOT NULL DEFAULT '0',
  `user_agent` varchar(120) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `user_data` text NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`) VALUES ('ceec3a9c9dcca5621d4b6eea8c853ae6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.167 Safari/537.36', '1518776398', 'a:7:{s:9:\"user_data\";s:0:\"\";s:9:\"logged_in\";s:13:\"aingLoginYeuh\";s:2:\"id\";N;s:8:\"username\";s:13:\"administrator\";s:12:\"nama_lengkap\";s:5:\"Owner\";s:4:\"foto\";s:12:\"IMG-f10a.jpg\";s:5:\"level\";s:2:\"01\";}');


#
# TABLE STRUCTURE FOR: config
#

DROP TABLE IF EXISTS `config`;

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `instansi` varchar(50) NOT NULL,
  `telp` text NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  `website` varchar(50) NOT NULL,
  `aplikasi` varchar(255) NOT NULL,
  `usaha` varchar(255) NOT NULL,
  `author` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `config` (`id`, `instansi`, `telp`, `alamat`, `email`, `website`, `aplikasi`, `usaha`, `author`) VALUES ('1', 'Bangunjiwo Software', '085747875865', 'Ds. Lemah dadi bangunjiwo kasihan bantul Yogyakarta', 'sales@bangunjiwo.com', 'www.domain.com', 'Aplikasi Inventori Produk', 'Desain Web,Sistem Informasi & Software Perkantoran', 'Ervin Santoso');


#
# TABLE STRUCTURE FOR: d_beli
#

DROP TABLE IF EXISTS `d_beli`;

CREATE TABLE `d_beli` (
  `idbeli` smallint(6) NOT NULL AUTO_INCREMENT,
  `kodebeli` char(15) NOT NULL,
  `kode_barang` char(15) NOT NULL,
  `jmlbeli` int(11) NOT NULL,
  `hargabeli` double NOT NULL,
  PRIMARY KEY (`idbeli`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `d_beli` (`idbeli`, `kodebeli`, `kode_barang`, `jmlbeli`, `hargabeli`) VALUES ('1', 'BL00001', 'ADD221', '10', '200000');
INSERT INTO `d_beli` (`idbeli`, `kodebeli`, `kode_barang`, `jmlbeli`, `hargabeli`) VALUES ('2', 'BL00002', 'SP0001', '1', '60000');


#
# TABLE STRUCTURE FOR: d_beli1
#

DROP TABLE IF EXISTS `d_beli1`;

CREATE TABLE `d_beli1` (
  `idbeli` smallint(6) NOT NULL AUTO_INCREMENT,
  `kodebeli` char(15) NOT NULL,
  `kode_barang` char(15) NOT NULL,
  `jmlbeli` int(11) NOT NULL,
  `hargabeli` double NOT NULL,
  PRIMARY KEY (`idbeli`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `d_beli1` (`idbeli`, `kodebeli`, `kode_barang`, `jmlbeli`, `hargabeli`) VALUES ('4', 'BL00001', 'ADD221', '1', '200000');


#
# TABLE STRUCTURE FOR: d_jual
#

DROP TABLE IF EXISTS `d_jual`;

CREATE TABLE `d_jual` (
  `idjual` smallint(6) NOT NULL AUTO_INCREMENT,
  `kodejual` char(15) NOT NULL,
  `kode_barang` char(15) NOT NULL,
  `jmljual` int(11) NOT NULL,
  `hargajual` double NOT NULL,
  `diskon` double NOT NULL,
  PRIMARY KEY (`idjual`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `d_jual` (`idjual`, `kodejual`, `kode_barang`, `jmljual`, `hargajual`, `diskon`) VALUES ('2', 'JL00001', 'ADD221', '10', '300000', '500000');


#
# TABLE STRUCTURE FOR: d_jual1
#

DROP TABLE IF EXISTS `d_jual1`;

CREATE TABLE `d_jual1` (
  `idjual` smallint(6) NOT NULL AUTO_INCREMENT,
  `kodejual` char(15) NOT NULL,
  `kode_barang` char(15) NOT NULL,
  `jmljual` int(11) NOT NULL,
  `hargajual` double NOT NULL,
  `diskon` double NOT NULL,
  PRIMARY KEY (`idjual`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `d_jual1` (`idjual`, `kodejual`, `kode_barang`, `jmljual`, `hargajual`, `diskon`) VALUES ('1', 'JL00001', 'ADD221', '2', '300000', '0');


#
# TABLE STRUCTURE FOR: h_beli
#

DROP TABLE IF EXISTS `h_beli`;

CREATE TABLE `h_beli` (
  `kodebeli` char(15) NOT NULL,
  `tglbeli` date NOT NULL,
  `kode_supplier` char(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`kodebeli`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `h_beli` (`kodebeli`, `tglbeli`, `kode_supplier`, `username`) VALUES ('BL00001', '2018-03-01', 'ADD22', 'administrator');
INSERT INTO `h_beli` (`kodebeli`, `tglbeli`, `kode_supplier`, `username`) VALUES ('BL00002', '2018-03-03', 'ADD22', 'administrator');


#
# TABLE STRUCTURE FOR: h_beli1
#

DROP TABLE IF EXISTS `h_beli1`;

CREATE TABLE `h_beli1` (
  `kodebeli` char(15) NOT NULL,
  `tglbeli` date NOT NULL,
  `kode_supplier` char(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`kodebeli`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `h_beli1` (`kodebeli`, `tglbeli`, `kode_supplier`, `username`) VALUES ('BL00001', '2018-03-03', 'ADD22', 'administrator');


#
# TABLE STRUCTURE FOR: h_booking
#

DROP TABLE IF EXISTS `h_booking`;

CREATE TABLE `h_booking` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `kodebooking` char(15) NOT NULL,
  `tglbooking` date NOT NULL,
  `jatuh_tempo` date NOT NULL,
  `kode_pelanggan` char(5) NOT NULL,
  `pelanggan` varchar(50) NOT NULL,
  `keterangan` char(1) NOT NULL,
  `dp` double NOT NULL,
  `username` varchar(50) NOT NULL,
  `kode_barang` char(15) NOT NULL,
  `jmlbooking` int(11) NOT NULL,
  PRIMARY KEY (`no`),
  KEY `kodebooking` (`kodebooking`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `h_booking` (`no`, `kodebooking`, `tglbooking`, `jatuh_tempo`, `kode_pelanggan`, `pelanggan`, `keterangan`, `dp`, `username`, `kode_barang`, `jmlbooking`) VALUES ('1', 'BK00001', '2018-03-03', '2018-03-03', 'UMUM', 'Yuda', '1', '540000', 'administrator', 'ADD220', '1');


#
# TABLE STRUCTURE FOR: h_booking1
#

DROP TABLE IF EXISTS `h_booking1`;

CREATE TABLE `h_booking1` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `kodebooking` char(15) NOT NULL,
  `tglbooking` date NOT NULL,
  `jatuh_tempo` date NOT NULL,
  `kode_pelanggan` char(5) NOT NULL,
  `pelanggan` varchar(50) NOT NULL,
  `keterangan` char(1) NOT NULL,
  `dp` double NOT NULL,
  `username` varchar(50) NOT NULL,
  `kode_barang` char(15) NOT NULL,
  `jmlbooking` int(11) NOT NULL,
  PRIMARY KEY (`no`),
  KEY `kodebooking` (`kodebooking`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `h_booking1` (`no`, `kodebooking`, `tglbooking`, `jatuh_tempo`, `kode_pelanggan`, `pelanggan`, `keterangan`, `dp`, `username`, `kode_barang`, `jmlbooking`) VALUES ('1', 'BK00001', '2018-03-03', '2018-03-03', 'UMUM', 'Yuda', '1', '540000', 'administrator', 'ADD220', '1');
INSERT INTO `h_booking1` (`no`, `kodebooking`, `tglbooking`, `jatuh_tempo`, `kode_pelanggan`, `pelanggan`, `keterangan`, `dp`, `username`, `kode_barang`, `jmlbooking`) VALUES ('2', 'BK00002', '2018-03-03', '2018-03-03', 'RES', 'Yunus', '2', '240000', 'administrator', 'ADD220', '1');


#
# TABLE STRUCTURE FOR: h_jual
#

DROP TABLE IF EXISTS `h_jual`;

CREATE TABLE `h_jual` (
  `kodejual` char(15) NOT NULL,
  `tgljual` date NOT NULL,
  `kode_pelanggan` char(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  `status` char(1) NOT NULL,
  `keterangan` char(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`kodejual`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `h_jual` (`kodejual`, `tgljual`, `kode_pelanggan`, `username`, `status`, `keterangan`) VALUES ('JL00001', '2018-03-03', 'RES', 'administrator', '1', '1');


#
# TABLE STRUCTURE FOR: h_jual1
#

DROP TABLE IF EXISTS `h_jual1`;

CREATE TABLE `h_jual1` (
  `kodejual` char(15) NOT NULL,
  `tgljual` date NOT NULL,
  `kode_pelanggan` char(5) NOT NULL,
  `username` varchar(50) NOT NULL,
  `status` char(1) NOT NULL,
  `keterangan` char(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`kodejual`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `h_jual1` (`kodejual`, `tgljual`, `kode_pelanggan`, `username`, `status`, `keterangan`) VALUES ('JL00001', '2018-03-03', 'UMUM', 'administrator', '1', '2');


#
# TABLE STRUCTURE FOR: level
#

DROP TABLE IF EXISTS `level`;

CREATE TABLE `level` (
  `id_level` char(2) NOT NULL,
  `level` char(30) NOT NULL,
  PRIMARY KEY (`id_level`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `level` (`id_level`, `level`) VALUES ('01', 'Super Admin');
INSERT INTO `level` (`id_level`, `level`) VALUES ('02', 'Admin');
INSERT INTO `level` (`id_level`, `level`) VALUES ('03', 'Kasir');


#
# TABLE STRUCTURE FOR: pelanggan
#

DROP TABLE IF EXISTS `pelanggan`;

CREATE TABLE `pelanggan` (
  `kode_pelanggan` char(5) NOT NULL DEFAULT '',
  `nama_pelanggan` varchar(50) NOT NULL,
  PRIMARY KEY (`kode_pelanggan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `pelanggan` (`kode_pelanggan`, `nama_pelanggan`) VALUES ('DRS', 'Dropshiper');
INSERT INTO `pelanggan` (`kode_pelanggan`, `nama_pelanggan`) VALUES ('RES', 'Reseller');
INSERT INTO `pelanggan` (`kode_pelanggan`, `nama_pelanggan`) VALUES ('UMUM', 'User');


#
# TABLE STRUCTURE FOR: sessions
#

DROP TABLE IF EXISTS `sessions`;

CREATE TABLE `sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jtuf7d6vl7hs0dea4hvj8tbiqi44qs8f', '127.0.0.1', '1519879155', '__ci_last_regenerate|i:1519879155;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lo3h4138apisatok7c4v0rfd87hup8oa', '127.0.0.1', '1519880155', '__ci_last_regenerate|i:1519880155;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r36nmk2m1bn7hi9egbh1ll9ibuqb6gfp', '127.0.0.1', '1519880561', '__ci_last_regenerate|i:1519880561;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('20jjo6k0kua6mivd5q120ania95u5k1q', '127.0.0.1', '1519881037', '__ci_last_regenerate|i:1519881037;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('818nmhghgr49fvakr7ki41ttqj6g9qu5', '127.0.0.1', '1519882063', '__ci_last_regenerate|i:1519882063;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bgq0p35ohs1av98j0ghfkn1p6fdnlg3a', '127.0.0.1', '1519882384', '__ci_last_regenerate|i:1519882384;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d5r0sfm7kc24869o2cmjvau77rukg7je', '127.0.0.1', '1519882689', '__ci_last_regenerate|i:1519882689;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fr39fpe8o6ph04edvcoiobtldgrpa9k8', '127.0.0.1', '1519883391', '__ci_last_regenerate|i:1519883391;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:4:\"user\";nama_lengkap|s:8:\"Hermawan\";foto|s:12:\"ava-8836.png\";level|s:2:\"03\";id_session|s:60:\"$2y$10$P9krK7Yufa.ZYuR5NMVWKuPLVNGa2fXwKiFpm9r/OBEr.YJo.7el6\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7vdm64htne7091ln9qsf3cbafsg6ha2f', '127.0.0.1', '1519883700', '__ci_last_regenerate|i:1519883700;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:4:\"user\";nama_lengkap|s:8:\"Hermawan\";foto|s:12:\"ava-8836.png\";level|s:2:\"03\";id_session|s:60:\"$2y$10$P9krK7Yufa.ZYuR5NMVWKuPLVNGa2fXwKiFpm9r/OBEr.YJo.7el6\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gho3j0ojjmg01uq9dk6g63gkndp8m1cl', '127.0.0.1', '1519884024', '__ci_last_regenerate|i:1519884024;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:4:\"user\";nama_lengkap|s:8:\"Hermawan\";foto|s:12:\"ava-8836.png\";level|s:2:\"03\";id_session|s:60:\"$2y$10$P9krK7Yufa.ZYuR5NMVWKuPLVNGa2fXwKiFpm9r/OBEr.YJo.7el6\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rn95tjdb1fs70ercbesl0781c3402qvc', '127.0.0.1', '1519884593', '__ci_last_regenerate|i:1519884593;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jkd21ripnbshnb0duqmp2h07ma3or885', '127.0.0.1', '1519884917', '__ci_last_regenerate|i:1519884917;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fnm43a1qk1hh637et4lku19ebmqls2q8', '127.0.0.1', '1519885334', '__ci_last_regenerate|i:1519885334;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('86e9jdkum06anaq9jk8174kfdikg0n2k', '127.0.0.1', '1519885747', '__ci_last_regenerate|i:1519885747;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ucfhfnpi6d0e5ggaqfip9rqnd046rb7b', '127.0.0.1', '1519886084', '__ci_last_regenerate|i:1519886084;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('et61hlifl97t3g06v1f88hsjhtchl27b', '127.0.0.1', '1519886698', '__ci_last_regenerate|i:1519886698;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h2e559o92u4133jimvp9rb11j3l9mmgv', '127.0.0.1', '1519887006', '__ci_last_regenerate|i:1519887006;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7darli3ppsri3p4ite0jdufq7emrfg1v', '127.0.0.1', '1519887395', '__ci_last_regenerate|i:1519887395;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('401geu2rm4icvm4tv70qdh3t87cvl2qc', '127.0.0.1', '1519887728', '__ci_last_regenerate|i:1519887728;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0mn5i52m6s6luai7pm93umhdv8lqu38l', '127.0.0.1', '1519888096', '__ci_last_regenerate|i:1519888096;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tiib84affu1l51rag6led0qiq2kitf1p', '127.0.0.1', '1519888406', '__ci_last_regenerate|i:1519888406;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4k3psp6lhpsemp1j3r5t9g75tdrhsl0t', '127.0.0.1', '1519888708', '__ci_last_regenerate|i:1519888708;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d1fbp2pfk2knq1n280k0n1l336b4sf68', '127.0.0.1', '1519889038', '__ci_last_regenerate|i:1519889038;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f0uqpd6jcadevbnirlvot8q8941b3r6u', '127.0.0.1', '1519889431', '__ci_last_regenerate|i:1519889431;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n78qi6nb2brdp7oha56ic1uakkatc0fv', '127.0.0.1', '1519889805', '__ci_last_regenerate|i:1519889805;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k17vvi2qjkngtvlfi2cdc4sa6494ibeh', '127.0.0.1', '1519890577', '__ci_last_regenerate|i:1519890577;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k3hj6r5t2jt7avrmgs0s5mtjkljon77i', '127.0.0.1', '1519890892', '__ci_last_regenerate|i:1519890892;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('06mvfbi2vos22nrvqh9r4ip6ogmopuml', '127.0.0.1', '1519891210', '__ci_last_regenerate|i:1519891210;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a8pjoijv699hv34ttmntcpdls8na5rpd', '127.0.0.1', '1519891518', '__ci_last_regenerate|i:1519891518;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8kv9u0v5m32dob0f08rie1fh30trg4ab', '127.0.0.1', '1519892300', '__ci_last_regenerate|i:1519892300;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('r8a2pulcl0cg8atrvpk94hialsghl6s2', '127.0.0.1', '1519892631', '__ci_last_regenerate|i:1519892631;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b03dhdi2ibg6l6oao7f8pf5u9tb4e9ga', '127.0.0.1', '1519892948', '__ci_last_regenerate|i:1519892948;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hhv9uoenfkvbmauuc3qvd3emf99q8fik', '127.0.0.1', '1519893669', '__ci_last_regenerate|i:1519893669;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j470k5djl1mf8ia04h92cg3osg5lminh', '127.0.0.1', '1519894174', '__ci_last_regenerate|i:1519894174;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:4:\"user\";nama_lengkap|s:8:\"Hermawan\";foto|s:12:\"ava-8836.png\";level|s:2:\"03\";id_session|s:60:\"$2y$10$P9krK7Yufa.ZYuR5NMVWKuPLVNGa2fXwKiFpm9r/OBEr.YJo.7el6\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n841vpk83krc282o1hrosc6c32jomigl', '127.0.0.1', '1519894563', '__ci_last_regenerate|i:1519894563;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mrcdpu688gv11h7t7mdqrm586g8l39ko', '127.0.0.1', '1519894870', '__ci_last_regenerate|i:1519894870;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jpcnkhs1kmh3615q3eq1ot5t2mvo97le', '127.0.0.1', '1519895703', '__ci_last_regenerate|i:1519895703;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:6:\"gudang\";nama_lengkap|s:5:\"Yunus\";foto|s:12:\"ava-677f.png\";level|s:2:\"02\";id_session|s:60:\"$2y$10$BcZ6h/mTQ.yt/8UkrSdIv.mK3xEBkIF/KdYoD2Bne/pjJMGEQtXcS\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3k98te91feeh210u9h3oa3mc00r8feu2', '127.0.0.1', '1519896327', '__ci_last_regenerate|i:1519896327;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nmhu8el5h1r3ia1p7rn7374831o2vjh3', '127.0.0.1', '1519897077', '__ci_last_regenerate|i:1519897077;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l49172uplt3n3ta64if7r1hfps1tp0kn', '127.0.0.1', '1519897722', '__ci_last_regenerate|i:1519897722;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q498dnmqtt9h8mj35s4mf5u76dojetc6', '127.0.0.1', '1519898023', '__ci_last_regenerate|i:1519898023;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ubq1fp1mdruba6e7kfkjsrfmdethd1b5', '127.0.0.1', '1519898291', '__ci_last_regenerate|i:1519898023;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1fg7bq0osm6t8khmlmspf7kg9g0pkd35', '127.0.0.1', '1519961404', '__ci_last_regenerate|i:1519961404;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1hu8pigqk7483f0v6m5nbc5onmgd5mr0', '127.0.0.1', '1519962636', '__ci_last_regenerate|i:1519961404;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m96fbgkqsitb2ft3buqa08nivtsdpvd8', '127.0.0.1', '1519982217', '__ci_last_regenerate|i:1519982217;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3b3cd2sqbookvsfj6qgqvd7ret4f11q6', '127.0.0.1', '1519982523', '__ci_last_regenerate|i:1519982523;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pn6t44cg50louehqve23mv1fi8cdijbn', '127.0.0.1', '1519983036', '__ci_last_regenerate|i:1519983036;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('53jb33s7hkvpm0phkodiskrt1uniqked', '127.0.0.1', '1519983343', '__ci_last_regenerate|i:1519983343;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9qqtv6hsb3tpn7b0p0b9jisv8odrrctn', '127.0.0.1', '1519983702', '__ci_last_regenerate|i:1519983702;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('18rrk1ia7mpci4e1gjiir3h1ajal40k8', '127.0.0.1', '1519984010', '__ci_last_regenerate|i:1519984010;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ckb83f557mi29f09clorau2b6ip0ig3l', '127.0.0.1', '1519984391', '__ci_last_regenerate|i:1519984391;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qqsjvac3gesjpol0urk4rapusgh33kd1', '127.0.0.1', '1519984702', '__ci_last_regenerate|i:1519984702;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('odfovu19mtd21rmfksht1r74at9uqt7i', '127.0.0.1', '1519984835', '__ci_last_regenerate|i:1519984702;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g9htu5effl0vqeap7hs1c5gv9rs0jehr', '127.0.0.1', '1520042633', '__ci_last_regenerate|i:1520042633;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hp9cl18klbpoqnfq4jrbgclr0k4jc8m7', '127.0.0.1', '1520042948', '__ci_last_regenerate|i:1520042948;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7v341khlf2838vh6sktsqe4g0265vrqb', '127.0.0.1', '1520043259', '__ci_last_regenerate|i:1520043259;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2nhfld3oqa27uunivc4d9800tccbl0ge', '127.0.0.1', '1520043588', '__ci_last_regenerate|i:1520043588;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0trjk10olt6krrafd8vdgd65t6ise8rm', '127.0.0.1', '1520043971', '__ci_last_regenerate|i:1520043971;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ahv9c058h557t3nfdc6spvpmbgoarmpe', '127.0.0.1', '1520044384', '__ci_last_regenerate|i:1520044384;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sm70smdmnpnrq3g4dq2udvdsll44j25s', '127.0.0.1', '1520044720', '__ci_last_regenerate|i:1520044720;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('c01dc6vpothvs0bj5jn86s66ccmnerl6', '127.0.0.1', '1520045197', '__ci_last_regenerate|i:1520045197;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('khfd6ctcdk61pfttqg1q6bp4lb231mib', '127.0.0.1', '1520045599', '__ci_last_regenerate|i:1520045599;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('t6mekbdh09bi9qfbm4hjp8t69bvehppd', '127.0.0.1', '1520045947', '__ci_last_regenerate|i:1520045947;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kis15832f98l3jsvh5qjkr1qu1lk4ivc', '127.0.0.1', '1520046516', '__ci_last_regenerate|i:1520046516;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k46760lrfnolasjsk85qr8blbti54sps', '127.0.0.1', '1520047168', '__ci_last_regenerate|i:1520047168;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('04b6l6saguek0lt3hhnr349ppkme3tgd', '127.0.0.1', '1520047524', '__ci_last_regenerate|i:1520047524;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vkph3r0u5b62o7gsbgsvfp4sko96ua4l', '127.0.0.1', '1520048433', '__ci_last_regenerate|i:1520048433;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('d6epbra95ldv3sjucp0tj05flts0e99v', '127.0.0.1', '1520049230', '__ci_last_regenerate|i:1520049230;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8p1rjsnf3ek5gpl97nuo4io85tof0mo8', '127.0.0.1', '1520049586', '__ci_last_regenerate|i:1520049586;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8tsodo6v0ff7moor0l58hb1rn4gvl7m5', '127.0.0.1', '1520050080', '__ci_last_regenerate|i:1520050080;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tmqk7pl43jesb948ki6sucgsfv51hbbq', '127.0.0.1', '1520050559', '__ci_last_regenerate|i:1520050559;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('90ohn70uf2p52e8kuljtm68ssa57ig6g', '127.0.0.1', '1520051363', '__ci_last_regenerate|i:1520051363;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0ifu6mlbo4fcj0qevp695bg792h2v7j3', '127.0.0.1', '1520051667', '__ci_last_regenerate|i:1520051667;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9jskk76qcru16ofefdrcqds77u8tp07q', '127.0.0.1', '1520051982', '__ci_last_regenerate|i:1520051982;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('og7i5brmi23fesl47r68o3oni9knk9j7', '127.0.0.1', '1520052283', '__ci_last_regenerate|i:1520052283;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g11rvculvstnp5ntfmc9jetu0f1e7efi', '127.0.0.1', '1520052600', '__ci_last_regenerate|i:1520052600;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bkua7bup73qsgke3m2qlcuc9glm9ijqg', '127.0.0.1', '1520052912', '__ci_last_regenerate|i:1520052912;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dejku3ajc321fh673djo0bkok0fk1mb0', '127.0.0.1', '1520053333', '__ci_last_regenerate|i:1520053333;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vda7t9v9rrdkuosp7jomv9s8ojhn6j3c', '127.0.0.1', '1520053642', '__ci_last_regenerate|i:1520053642;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vrdfo2uq0i0jnkmkptjrjuteqvs9h60n', '127.0.0.1', '1520054132', '__ci_last_regenerate|i:1520054132;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qemjp9ve8a4d00maqt8gor9cj4anfoh9', '127.0.0.1', '1520054473', '__ci_last_regenerate|i:1520054473;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i28qs41l94sellarntq3t0uouqkk0vr4', '127.0.0.1', '1520054852', '__ci_last_regenerate|i:1520054852;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p3ip2jp6q0st52vrqi6pip7aq0mobn2l', '127.0.0.1', '1520055164', '__ci_last_regenerate|i:1520055164;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('goikiv595apatdnr68fk5ijkbrv3er5q', '127.0.0.1', '1520055471', '__ci_last_regenerate|i:1520055471;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ert1nmkihfc73fb7i9uk4da2ttjj84t5', '127.0.0.1', '1520055823', '__ci_last_regenerate|i:1520055823;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vb1sp46u4ieltcnbe7pvp1hk6cbn261i', '127.0.0.1', '1520056156', '__ci_last_regenerate|i:1520056156;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('he3j2tdousfjspbcmnoui058f4ppasr3', '127.0.0.1', '1520056486', '__ci_last_regenerate|i:1520056486;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qshhg6dbjq5espcg13aakas2dk9u56bm', '127.0.0.1', '1520056791', '__ci_last_regenerate|i:1520056791;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('pmpp24ru9ib4irnq6cu0lc76j46bdp7v', '127.0.0.1', '1520057110', '__ci_last_regenerate|i:1520057110;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eeuq8bl5hpj8pl4k3in655nblto7ujrt', '127.0.0.1', '1520057456', '__ci_last_regenerate|i:1520057456;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hf1uolfsucduibg69mam3mq49d6s2a7n', '127.0.0.1', '1520057864', '__ci_last_regenerate|i:1520057864;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rlnlc8j3rbpaskfp0e6jpc3v355n79hg', '127.0.0.1', '1520058169', '__ci_last_regenerate|i:1520058169;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dnn368416p64h0nn34np2nsjrop96acp', '127.0.0.1', '1520058474', '__ci_last_regenerate|i:1520058474;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6q0g1ckjknimd7271dmtejrb7l7riiul', '127.0.0.1', '1520058776', '__ci_last_regenerate|i:1520058776;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('3eqfjc8bm2rf5q73jp6qc9sn65rmni87', '127.0.0.1', '1520059096', '__ci_last_regenerate|i:1520059096;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k51eqr2ttq4qorejtdvqbdec1g9rqh4m', '127.0.0.1', '1520059453', '__ci_last_regenerate|i:1520059453;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kaumauob0hq8r3762kqh380j19v2t831', '127.0.0.1', '1520059877', '__ci_last_regenerate|i:1520059877;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:6:\"gudang\";nama_lengkap|s:5:\"Yunus\";foto|s:12:\"ava-677f.png\";level|s:2:\"02\";id_session|s:60:\"$2y$10$BcZ6h/mTQ.yt/8UkrSdIv.mK3xEBkIF/KdYoD2Bne/pjJMGEQtXcS\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lj1fr87o2pa9lcno8b4ghsvg8tha686i', '127.0.0.1', '1520060446', '__ci_last_regenerate|i:1520060446;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('turensc3c7brdoa3173c7itpqe7v63mm', '127.0.0.1', '1520061111', '__ci_last_regenerate|i:1520061111;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:0:\"\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j2v0d1jdng2n1jnhlfjhdb77n72905j6', '127.0.0.1', '1520061507', '__ci_last_regenerate|i:1520061507;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:0:\"\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8mdej5iqvp0i9ai3e14ic4a0783movi7', '127.0.0.1', '1520063399', '__ci_last_regenerate|i:1520063399;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5j299l4dp2dp0vd70mm8v5qcgp7p2r5t', '127.0.0.1', '1520063906', '__ci_last_regenerate|i:1520063906;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vdshla8m57cbokl6kbhg8j36s1jocgcq', '127.0.0.1', '1520063592', '__ci_last_regenerate|i:1520063591;');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5vitokoobnon2jv0301svqc13vhb0098', '127.0.0.1', '1520064233', '__ci_last_regenerate|i:1520064233;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('onsc5asi8bdlg17lsibt26c80u9a82dh', '127.0.0.1', '1520064728', '__ci_last_regenerate|i:1520064728;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:2:\"01\";id_session|s:60:\"$2y$10$i/TfOS.DhcipE55aPw7fk.Q3NYdNzS2FOJlZfQHYz0cZ/azj3Ngla\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g9m8itd9sniiudjs98rf47ues7s3cps9', '127.0.0.1', '1520065141', '__ci_last_regenerate|i:1520065141;');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('221ed9ngt98td09262q9bap5ab0nlrjk', '127.0.0.1', '1520066176', '__ci_last_regenerate|i:1520066176;');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kl32fnhar40c4g54ru10jj79ae2bvpt4', '127.0.0.1', '1520067066', '__ci_last_regenerate|i:1520067066;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9kpqmdjqp8e1mdbfo0vhd0tpd0fr5uc2', '127.0.0.1', '1520067647', '__ci_last_regenerate|i:1520067647;');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('074rkq8i3jqli5su0uojf7d7rn9jcevg', '112.215.240.105', '1520228380', '__ci_last_regenerate|i:1520228132;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eqcbdtmraghdf3mcu5hg9ltsehb9d83h', '112.215.240.105', '1520229673', '__ci_last_regenerate|i:1520229673;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bqd6ia6l1i8palstm0rfopu8c4j9n390', '112.215.240.105', '1520230625', '__ci_last_regenerate|i:1520230625;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cn3ih7mo8dlrejfhdig8smvbkp6picdh', '112.215.240.105', '1520231313', '__ci_last_regenerate|i:1520231077;');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ofbba0gblbpbpfr056dv271a0ucghmj4', '112.215.240.105', '1520231521', '__ci_last_regenerate|i:1520231521;');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q9k9vl189igc09fbmkghlas8jqofmu06', '112.215.240.105', '1520232041', '__ci_last_regenerate|i:1520231526;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e6h6oid27p9rgght5s24te0rullbcelg', '112.215.240.105', '1520232363', '__ci_last_regenerate|i:1520232044;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5h5hs6adecr6jqg1bb69ukkrfa2r8ioh', '112.215.240.105', '1520232652', '__ci_last_regenerate|i:1520232364;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('crt279oid7ncs7fol9o13sqvjkib8sh8', '112.215.240.105', '1520232816', '__ci_last_regenerate|i:1520232666;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nj9dqoucsv8anp5f4jccknc415rumrv9', '112.215.240.105', '1520233434', '__ci_last_regenerate|i:1520233149;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cneu4jo9bkfbvgcq0f9flq02h8bgcmeu', '112.215.240.105', '1520233739', '__ci_last_regenerate|i:1520233512;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1c5j0sgd8mskrb1lvllgtil6v16uq9n1', '112.215.240.105', '1520234170', '__ci_last_regenerate|i:1520233975;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7j8up6uj9brrv3hurdi6taca5mlojjtp', '112.215.240.105', '1520234934', '__ci_last_regenerate|i:1520234641;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:5:\"dinda\";nama_lengkap|s:5:\"dinda\";foto|s:0:\"\";level|s:2:\"03\";toko|s:2:\"01\";id_session|s:60:\"$2y$10$mycKJnnvg9UG.wDnSoeJ/.XW/ofd6VowSaUcjskr80CXX19Am0AIy\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nfiugo4la6f8q3o30ld0tl5ck6l8hes8', '112.215.240.105', '1520235303', '__ci_last_regenerate|i:1520235197;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:5:\"dinda\";nama_lengkap|s:5:\"dinda\";foto|s:0:\"\";level|s:2:\"03\";toko|s:2:\"01\";id_session|s:60:\"$2y$10$mycKJnnvg9UG.wDnSoeJ/.XW/ofd6VowSaUcjskr80CXX19Am0AIy\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6rqag0du81vjtkj2o815832gbj2lel3g', '112.215.240.105', '1520235622', '__ci_last_regenerate|i:1520235600;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:5:\"dinda\";nama_lengkap|s:5:\"dinda\";foto|s:0:\"\";level|s:2:\"03\";toko|s:2:\"01\";id_session|s:60:\"$2y$10$mycKJnnvg9UG.wDnSoeJ/.XW/ofd6VowSaUcjskr80CXX19Am0AIy\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o0377b32pg5vmismjvushkh270vel23m', '112.215.240.105', '1520236425', '__ci_last_regenerate|i:1520236129;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vgfv152a0t5tcjrp8m0a92084k5uq0ka', '112.215.240.105', '1520236433', '__ci_last_regenerate|i:1520236433;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gn9ack6llak12cpeqgp5rcl4d4lsicqc', '112.215.240.105', '1520236435', '__ci_last_regenerate|i:1520236435;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kulqifbl402v0nk4c3ln5n9473dkubon', '112.215.240.105', '1520236537', '__ci_last_regenerate|i:1520236467;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('metvh2lqrpn4rr95olkjpe5sin63o8bk', '112.215.240.105', '1520237174', '__ci_last_regenerate|i:1520237049;');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dsn6s7i2r035qub0efro0tvgrg84s97v', '112.215.240.105', '1520237620', '__ci_last_regenerate|i:1520237482;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('bbqo4rv30cs3psn16pvgv8b3pc1ng4iq', '112.215.240.105', '1520237883', '__ci_last_regenerate|i:1520237883;');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('849458oajqlgs1bvo172eek9s2jqam7m', '112.215.240.105', '1520238649', '__ci_last_regenerate|i:1520238613;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5g26k85b5vr1j6r79ic9rgkuccquhvdc', '114.124.210.58', '1520238765', '__ci_last_regenerate|i:1520238765;');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('k76ataf572t3mejkluo4o6u5fc67an0b', '112.215.240.105', '1520239020', '__ci_last_regenerate|i:1520238965;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oomt6kmabb6br860c8m1f5h5gcq0mvf1', '112.215.240.105', '1520239265', '__ci_last_regenerate|i:1520239121;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:6:\"gudang\";nama_lengkap|s:5:\"Yunus\";foto|s:12:\"ava-677f.png\";level|s:2:\"02\";toko|s:5:\"01,02\";id_session|s:60:\"$2y$10$iAvPWzAtFqAE.VDL0HC8kuJTSvRfpbknAmau2pKwEpS9G/ql4Oozy\";');
INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e7buf2d00fjfh74petaqg2njaqg323fc', '112.215.240.105', '1520240239', '__ci_last_regenerate|i:1520240111;logged_in|s:13:\"aingLoginYeuh\";id|N;username|s:13:\"administrator\";nama_lengkap|s:5:\"Owner\";foto|s:12:\"IMG-f10a.jpg\";level|s:2:\"01\";toko|s:5:\"02,01\";id_session|s:60:\"$2y$10$LPJmRoRwDZooFdQd0dsT2uT/vuRABtn/Hl5D1LBJd9xHEXwksl0MW\";');


#
# TABLE STRUCTURE FOR: supplier
#

DROP TABLE IF EXISTS `supplier`;

CREATE TABLE `supplier` (
  `kode_supplier` char(5) NOT NULL DEFAULT '',
  `nama_supplier` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  PRIMARY KEY (`kode_supplier`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `supplier` (`kode_supplier`, `nama_supplier`, `alamat`) VALUES ('ADD22', 'ADIDAS SHOES', 'DS. Gedangan Kebon Jeruk Bantul Yogyakarta');


#
# TABLE STRUCTURE FOR: toko
#

DROP TABLE IF EXISTS `toko`;

CREATE TABLE `toko` (
  `id_toko` char(2) NOT NULL,
  `toko` char(30) NOT NULL,
  PRIMARY KEY (`id_toko`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `toko` (`id_toko`, `toko`) VALUES ('01', 'Jogja');
INSERT INTO `toko` (`id_toko`, `toko`) VALUES ('02', 'Solo');


